package com.niit.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="Blogcomment")
public class BlogComment {
	@Id
	private int id;
	@ManyToOne
	private BlogPost blogPost;
	@ManyToOne
	private User CommentBy;
	private String CommentTxt;
	private Date CommentedOn;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public BlogPost getBlogPost() {
		return blogPost;
	}
	public void setBlogPost(BlogPost blogPost) {
		this.blogPost = blogPost;
	}
	public User getCommentBy() {
		return CommentBy;
	}
	public void setCommentBy(User commentBy) {
		CommentBy = commentBy;
	}
	public String getCommentTxt() {
		return CommentTxt;
	}
	public void setCommentTxt(String commentTxt) {
		CommentTxt = commentTxt;
	}
	public Date getCommentedOn() {
		return CommentedOn;
	}
	public void setCommentedOn(Date commentedOn) {
		CommentedOn = commentedOn;
	}
	@Override
	public String toString() {
		return "BlogComment [id=" + id + ", blogPost=" + blogPost + ", CommentBy=" + CommentBy + ", CommentTxt="
				+ CommentTxt + ", CommentedOn=" + CommentedOn + "]";
	}

}
