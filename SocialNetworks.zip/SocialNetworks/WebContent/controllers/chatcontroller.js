/**
 * 
 * @param $rootScope
 * @param $scope
 * @param ChatService
 * @returns
 */


app.controller('ChatCtrl',  function($rootScope ,$scope, ChatService) {
    alert('entering chat controller')
    $scope.messages = [];
    $scope.message = "";
    $scope.max = 140;
    
    $scope.addMessage = function() {
      $scope.message.username=$rootScope.loggedInUser.firstname;
      ChatService.send($scope.message);
      $scope.message = "";
    };
    
    ChatService.receive().then(null, null, function(message) {
      message.username=$rootScope.loggedInUser.firstname;
      $scope.messages.push(message);
    });
  });

