app.controller('FriendController',function($scope,$http,$location)
{
$scope.friend={friendId:0,userName:'',friendName:'',status:''};

$scope.allFriendRequest;

function fetchAllFriendRequests()
{
$http.get("http://localhost:9080/CollaborationMiddleWare/getAllFriendRequest")
    .then(function(response)
	{
	$scope.allFriendRequest=response.data;
	console.log($scope.allFriendRequest);
	});
	}
	fetchAllFriendRequests();
	
	$scope.reject=function(friendId)
	{
		$http.get("http://localhost:9080/CollaborationMiddleWare/RejectFriendRequest/"+friendId)
		.success(function(response)
				{
			console.log("Friend request Rejected");
				});
	};
	
	$scope.approve=function(friendId)
	{
		$http.get("http://localhost:9080/CollaborationMiddleWare/approvalFriendRequest/"+friendId)
		.success(function(response)
				{
			console.log("Friend request accepted");
				});
	};
	
	$scope.addFriend=function()
	{
		console.log("sending friend request");
		$http.post("http://localhost:9080/CollaborationMiddleWare/createFriendRequest",$scope.friend)
		.then(function(response){
			console.log("request send");
		});
		};
	
	
	
	});
	
 