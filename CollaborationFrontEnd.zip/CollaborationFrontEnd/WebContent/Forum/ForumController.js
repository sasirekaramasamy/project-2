app.controller('ForumController',function($scope,$http,$location)
		
{
	$scope.forum={forumId:0,forumName:'',forumContent:'',creationDate:'',status:'',userName:''};
	$scope.forumdata;
	
	function fetchAllForums()
	{
	console.log('Fetching Forums');
	$http.get("http://localhost:9080/CollaborationMiddleWare/getAllForums")
	     .then(function(response){
		$scope.forumdata=response.data;
	     });
		
	};
	fetchAllForums();
	
	$scope.insertforum=function()
	{
		console.log('Entered into Insert Forum');
		$http.post('http://localhost:9080/CollaborationMiddleWare/insertForum',$scope.forum)
		   .then(fetchAllForums(),function(response)
				   {
			   console.log("Forum entered Successfully");
			   $scope.refresh();
			   $location.path("/Forum");
				   });
	};
	
	$scope.deleteForum=function(forumId){
		console.log('Entered into Delete Forum');
		$http.get("http://localhost:9080/CollaborationMiddleWare/deleteForum/"+forumId)
		.success(fetchAllForums(),function(response){
			console.log('Successful Deletion');	
			$scope.refresh();
			$location.path("/Forum")
			
		});
	};
	
	
	
	
	
	});