package com.niit.collaborationbackend;

import static org.junit.Assert.*;
import java.util.List;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collaborationbackend.config.ApplicationContextConfig;
import com.niit.collaborationbackend.dao.FriendDao;
import com.niit.collaborationbackend.model.Friend;


public class FriendDaoTest {

	static FriendDao friendDao;
	int currentFrinedId;
	String currentFriendName;

	@BeforeClass
	public static void initialize() {
		AnnotationConfigApplicationContext annotationConfigAppContext=new AnnotationConfigApplicationContext(ApplicationContextConfig.class);
		annotationConfigAppContext.scan("com.niit");
		//	annotationConfigAppContext.refresh();
		friendDao=(FriendDao)annotationConfigAppContext.getBean(FriendDao.class);
	}


	public void addFriendTest()
	{
		Friend friend=new Friend();
		friend.setFriendName("Sasi");
		friend.setUserName("Reka");
		friend.setStatus("R");
		assertTrue("Failure",friendDao.createFriend(friend));
		System.out.println("insertFrined:"+friend);

	}
	
	public void getFriendTest()
	{
		Friend friend=friendDao.getFriend(currentFrinedId);
		
		assertTrue("Failure",friendDao.createFriend(friend));
		System.out.println("insertFrined:"+friend);

	}


	public void getAllFriendRequestTest()
	{
		List<Friend>listFriends=friendDao.getAllFriendRequest("Reka");
		assertNotNull("problem in list friends",listFriends);
		System.out.println("getAllFrinedRequests:"+listFriends);		
		for(Friend friend:listFriends) {
			System.out.println(friend);
			currentFrinedId=friend.getFriendId();
			currentFriendName=friend.getFriendName();
		}
	}

	public void approveFriendRequestTest()
	{
		Friend friend=friendDao.getFriend(currentFrinedId);
		System.out.println("approveFrinedRequest:"+friend);
		assertTrue("problem in approving",friendDao.approveFriendRequest(friend));
		System.out.println("approveFrinedRequest:"+friend);
	}

	public void rejectFriendRequestTest()
	{
		Friend friend=friendDao.getFriend(currentFrinedId);
		assertTrue("problem in rejecting",friendDao.rejectFriendRequest(friend));
		System.out.println("rejectFrinedRequest:"+friend);
	}

	public void getAllApprovedFriendTest()
	{
		List<Friend>listFriends=friendDao.getApprovedFriends("Reka");
		assertNotNull("problem in List Friends",listFriends.get(0));
		System.out.println("getAllApprovedFrineds:");
		for(Friend friend:listFriends) {
			System.out.println(friend);
			currentFrinedId=friend.getFriendId();
		}
	}

	@Test
	public void executeTestMethods() {
		addFriendTest();
		getAllFriendRequestTest();		
		approveFriendRequestTest();
		getAllApprovedFriendTest();
		rejectFriendRequestTest();
	}
}
