package com.niit.collaborationbackend;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collaborationbackend.config.ApplicationContextConfig;
import com.niit.collaborationbackend.dao.UserDao;
import com.niit.collaborationbackend.model.UserInfo;

public class UserDaoTest {


	static UserDao userDao;
	int currentUserId;
	String currentUser;
	
	@BeforeClass
	public static void initialize() {
		AnnotationConfigApplicationContext annotationConfigAppContext=new AnnotationConfigApplicationContext(ApplicationContextConfig.class);
		annotationConfigAppContext.scan("com.niit");
//		annotationConfigAppContext.refresh();
		userDao=(UserDao)annotationConfigAppContext.getBean(UserDao.class);
	 }
	
	public void addUserTest()
	{
		UserInfo user=new UserInfo();
//		user.setUserId(2);
		user.setUserName("sasi");
		user.setFirstName("sasi");
		user.setLastName("reka");
		user.setEmailId("sasireka@gmail.com");
		user.setPassword("sasireka123");
		user.setIsOnline("N");
		user.setRole("Admin");
		assertTrue("problem in creating user",userDao.addUser(user));
     }

	public void isOnlineTest()
	{
		UserInfo user=userDao.getUser(currentUser);
		assertTrue("problem in updation",userDao.updateOnlineStatus("N", user));
				
	}

	public void getUserTest()
	    {
	    	UserInfo user=userDao.getUser(currentUser);
	    	assertNotNull("User not found",user);
	    }

	public void getAllUsersTest()
	{
		List<UserInfo>userlist=(List<UserInfo>)userDao.getAllUser();
		assertNotNull("user list not found",userlist.get(0));
		currentUserId=userlist.get(0).getUserId();
		currentUser=userlist.get(0).getUserName();
	}

	public void checkLoginTest()
	{
		UserInfo  user=new UserInfo();
		user.setUserName("sasi");
		user.setPassword("sasireka123");
//		currentUser=user.getUserName();
		assertNotNull("problem in Login",userDao.checkLogin(user));
	}
	
	public void deleteUserTest() {
		System.out.println("delete:"+currentUser);
		UserInfo user=userDao.getUser(currentUser);	
		System.out.println("user:"+user);
    	assertNotNull("User not found",userDao.delete(user.getEmailId()));
	}
	
	@Test
	public void executeTest() {
		addUserTest();
		getAllUsersTest();
		getUserTest();
		isOnlineTest();
		checkLoginTest();
		deleteUserTest();
	}
	}
