package com.niit.collaborationbackend;

import static org.junit.Assert.*;

import java.util.Date;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collaborationbackend.config.ApplicationContextConfig;
import com.niit.collaborationbackend.dao.BlogDao;
import com.niit.collaborationbackend.model.Blog;

public class BlogDaoTest {

	static BlogDao blogDao;
	
	 @BeforeClass
		public static void initialize() {
		AnnotationConfigApplicationContext annotationConfigAppContext=new AnnotationConfigApplicationContext(ApplicationContextConfig.class);
		annotationConfigAppContext.scan("com.niit");
//		annotationConfigAppContext.refresh();
		blogDao=(BlogDao)annotationConfigAppContext.getBean(BlogDao.class);
	 }
	
	@Ignore
	@Test
	public void addBlogTest() {
		Blog blog=new Blog();
		blog.setUserName("Bindhu");
		blog.setBlogName("HTML");
		blog.setBlogContent("Based on HTML5");
		blog.setStatus("R");
		blog.setLikes(1);
		blog.setCreationDate(new Date());
		System.out.println(blog);
		assertTrue("Problem in Inserting Blog",blogDao.addBlog(blog));
    }
    
	@Test
    public void getBlogTest()
    {
    	Blog blog=blogDao.getBlog(80);
    	assertNotNull("Blog not found",blog);
    	System.out.println("getBlog:"+blog);
    }
    
    @Test
    public void updateBlogTest() {
    	Blog blog=blogDao.getBlog(80);
    	blog.setBlogContent("Clientside MVC Framework");
    	assertTrue("problem in updating blog",blogDao.updateBlog(blog));
    	System.out.println("updateBlog"+blog);
     }
    
    @Test
    public void getAllBlogTest()
    {
    	List<Blog>bloglist=(List<Blog>)blogDao.getAllBlogs();
    	assertNotNull("Blog list not found",bloglist.get(0));
    	System.out.println("getAllBlogs:");
    	for (Blog blog:bloglist)
    	{
    		System.out.println(blog);
    	}
    }
    
    @Test
    public void rejectBlogTest()
    {
    	Blog blog=(Blog)blogDao.getBlog(80);
    	assertTrue("problem in rejecting blog",blogDao.rejectBlog(blog));
    	System.out.println("rejectBlog:"+blog);
    }
    
    @Test
    public void approveBlogTest()
    {
    	Blog blog=(Blog)blogDao.getBlog(80);
    	assertTrue("problem in aproving blog",blogDao.approveBlog(blog));
    	System.out.println("approveBlog:"+blog);
    }
    
    @Test
	public void incLikesBlogTest()
	{
		Blog blog=blogDao.getBlog(80);
		assertTrue("problem in incrementing likes",blogDao.incLikes(blog));
		System.out.println("increaseLikesBlog:"+blog);
	}
    
    @Test
    public void deleteBlogTest()
    {
    	Blog blog=(Blog)blogDao.getBlog(80);
    	assertTrue("problem in deleting blog",blogDao.deleteBlog(blog));
    	System.out.println("deleteBlog:"+blog);
    }
    
    
   

}
