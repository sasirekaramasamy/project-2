package com.niit.collaborationbackend;

import static org.junit.Assert.*;
import java.util.Date;
import java.util.List;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collaborationbackend.config.ApplicationContextConfig;
import com.niit.collaborationbackend.dao.JobDao;
import com.niit.collaborationbackend.model.JobInfo;

public class JobDaoTest {

	static JobDao jobDao;
	int currentJobId;
	
	@BeforeClass
	public static void initialize() {
		AnnotationConfigApplicationContext annotationConfigAppContext=new AnnotationConfigApplicationContext(ApplicationContextConfig.class);
		annotationConfigAppContext.scan("com.niit");
		//		annotationConfigAppContext.refresh();
		jobDao=(JobDao)annotationConfigAppContext.getBean(JobDao.class);
	}

	public void addJobTest()
	{
		JobInfo job=new JobInfo();
//		job.setJobId(1);
		job.setJobProfile("IT");
		job.setJobDescription("Java");
		job.setPostDate(new Date());
		job.setQualification("BE");
		job.setStatus("A");
		assertTrue("problem in adding job",jobDao.addJob(job));
	}

	public void getJoblistTest()
	{
		List<JobInfo>joblist=(List<JobInfo>)jobDao.getJoblist();
		assertNotNull("Job not found",joblist.get(0));
		currentJobId=joblist.get(0).getJobId();
	}

	public void getJobByIdTest()
	{
		JobInfo job=jobDao.getJobById(currentJobId);
		assertNotNull("Job not found",job);
		System.out.println("JobProfile:"+job.getJobProfile());
		System.out.println("JobQualification:"+job.getQualification());
	}

	public void updateJobTest()
	{
		JobInfo job=jobDao.getJobById(currentJobId);
		job.setQualification("B.Tech");
		assertTrue("problem in updating job",jobDao.updateJob(job));
		System.out.println("JobProfile:"+job.getJobProfile());
		System.out.println("JobQualification:"+job.getQualification());
	}

	public void deleteJobTest()
	{
		JobInfo job=jobDao.getJobById(currentJobId);
		assertTrue("problem in deletion",jobDao.deleteJob(job));
	}	 	 

	@Test
	public void executeTestMethods() {
		addJobTest();
		getJoblistTest();
		getJobByIdTest();
		updateJobTest();
		deleteJobTest();
	}
}