package com.niit.collaborationbackend;

import static org.junit.Assert.*;


import java.util.Date;
import java.util.List;

import javax.swing.text.DefaultEditorKit.CutAction;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collaborationbackend.config.ApplicationContextConfig;
import com.niit.collaborationbackend.dao.ForumDao;
import com.niit.collaborationbackend.model.Forum;

public class ForumDaoTest {

	static ForumDao forumDao;
	int currentForumId;

	@BeforeClass
	public static void initialize() {
		AnnotationConfigApplicationContext annotationConfigAppContext=new AnnotationConfigApplicationContext(ApplicationContextConfig.class);
		annotationConfigAppContext.scan("com.niit");
//		annotationConfigAppContext.refresh();
		forumDao=(ForumDao)annotationConfigAppContext.getBean(ForumDao.class);
	}

	public void addForumTest() {
		Forum forum=new Forum();
		forum.setForumName("Stackflow");
		forum.setForumContent("JAVA");
		forum.setUserName("Sanjay");
		forum.setStatus("A");
		forum.setCreationDate(new Date());
		assertTrue("Problem in inserting forum",forumDao.addForum(forum));
		System.out.println("insertForum:"+forum);
	}

	public void getForumTest()
	{
		Forum forum=forumDao.getForum(currentForumId);
		assertNotNull("Forum not found",forum);
		System.out.println("getForum:" +forum);
		
	}
	
	public void updateForumTest()
	{
		Forum forum=forumDao.getForum(currentForumId);
		forum.setForumContent(".NET");
		assertTrue("problem in updating forum",forumDao.updateForum(forum));
		System.out.println("updateForum:" +forum);
		
	}

	public void getAllForumTest()
	{
		List<Forum>forumlist=(List<Forum>)forumDao.getAllForums();
		assertNotNull("forumlist not found",forumlist.get(0));
		System.out.println("getAllForums:");
		for (Forum forum:forumlist)
		{
			System.out.println("Forum" + forum);
			currentForumId=forum.getForumId();
		}
	}

	public void rejectForumTest()
	{
		Forum forum=forumDao.getForum(currentForumId);
		assertTrue("problem in rejecting forum",forumDao.rejectForum(forum));
		System.out.println("rejectForum:"+forum);
	}

	public void approveForumTest()
	{
		Forum forum=forumDao.getForum(currentForumId);
		assertTrue("problem in approving forum",forumDao.approveForum(forum));
		System.out.println("approveForum:"+forum);
	}
	
	public void deleteForumTest()
	{
		Forum forum=(Forum)forumDao.getForum(currentForumId);
		assertTrue("problem in deleting forum",forumDao.deleteForum(forum));
		System.out.println("deleteForum:"+forum);
	}
	
	@Test
	public void executeTestMethods() {
		addForumTest();
		getAllForumTest();
		getForumTest();
		updateForumTest();
		rejectForumTest();
		approveForumTest();
		deleteForumTest();
	}

}
