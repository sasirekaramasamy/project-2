package com.niit.collaborationbackend.dao;

import com.niit.collaborationbackend.model.Profilepic;

public interface ProfilepicDao {
	
	public boolean save(Profilepic profilepic);
	public Profilepic getProfilepic(String userName);

}
