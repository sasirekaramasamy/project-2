package com.niit.collaborationbackend.dao;

import java.util.List;

import com.niit.collaborationbackend.model.JobInfo;

public interface JobDao {
	public boolean addJob(JobInfo job);
	public boolean updateJob(JobInfo job);
	public boolean deleteJob(JobInfo job);
	public JobInfo getJobById(int jobId);
	public List<JobInfo> getJoblist();
}
